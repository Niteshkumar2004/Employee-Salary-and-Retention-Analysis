# Employee Salary and Retention Analysis

Author: Nitesh Kumar

This project simulates employee data and performs a full statistical analysis of:

- Salary distribution and descriptive statistics
- Attrition rate by education level
- Correlation between salary, experience, and age
- Central Limit Theorem (CLT) demonstration using sample means
- Hypothesis testing (one-sample t-test, two-sample t-test, two-proportion z-test)
- Multiple linear regression for salary prediction
- Poisson regression (GLM) for modelling number of projects

## Files

- `Employee_Salary_and_Retention_Analysis.py`  
  Main Python script that generates the data, runs all analyses, and saves plots.

- `output/`
  - `attrition_by_education.png` – stacked bar chart of attrition proportion by education level  
  - `correlation_matrix.png` – heatmap of correlations between salary, experience, and age  
  - `clt_distribution.png` – histogram of sample mean salaries illustrating the CLT  

  > These images are created automatically when you run the script.

## How to Run

1. Create and activate a Python environment (optional but recommended).
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Run the analysis:
   ```bash
   python Employee_Salary_and_Retention_Analysis.py
   ```

After running, check the `output/` folder for the generated figures.

## Example Results (Summary)

- **Descriptive Statistics:**  
  The script reports the 25th percentile, 75th percentile, and interquartile range (IQR) of salaries, giving a robust sense of the middle spread of employee pay.

- **Attrition vs. Education:**  
  A stacked bar chart shows the proportion of employees leaving (`Yes`) vs. staying (`No`) for each education level, allowing you to visually compare retention across groups.

- **Correlation Matrix:**  
  A heatmap displays the strength of relationships between salary, experience, and age. In the simulated data, salary is strongly and positively related to experience.

- **Central Limit Theorem:**  
  Using repeated samples from the salary distribution, the histogram of sample means approaches a normal distribution, even though the original salary distribution may not be perfectly normal.

- **Hypothesis Testing:**  
  The script performs:
  - A one-sample t-test comparing mean salary to a benchmark value.  
  - A two-sample t-test comparing average salaries between Engineering and Sales departments.  
  - A two-proportion z-test comparing attrition rates between Sales and Support.

- **Multiple Linear Regression:**  
  Salary is regressed on years of experience and education levels. Coefficients can be interpreted as:
  - Additional salary per year of experience (holding education constant).  
  - Salary differences between education categories (holding experience constant).

- **Poisson Regression (GLM):**  
  Number of projects is modeled as a function of age and having a Master's degree.  
  The exponentiated coefficients show multiplicative effects (e.g., Master's holders may complete a higher expected number of projects than others).

You can modify the simulation parameters (sample size, effect sizes, etc.) to explore different HR analytics scenarios.

---

Feel free to fork or extend this project to include real datasets, dashboarding (Power BI / Tableau), or additional models.
