# Employee Salary and Retention Analysis
# --------------------------------------
# This script simulates employee data and performs:
# - Descriptive statistics
# - Visualization & correlation analysis
# - Central Limit Theorem simulation
# - Hypothesis testing
# - Multiple linear regression
# - Poisson regression (GLM)

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import statsmodels.api as sm
from scipy import stats

# Ensure output directory exists for saving figures
os.makedirs("output", exist_ok=True)

# ----------------------------------------------------------------------
# STEP 1: SETUP, DATA SIMULATION, AND DESCRIPTIVE STATISTICS
# ----------------------------------------------------------------------
print("STEP 1: Setup, Data Simulation, and Descriptive Statistics")

# Set random seed for reproducibility
np.random.seed(42)

# --- Data Simulation ---
n = 300
experience = np.random.randint(1, 25, n)
age = 22 + experience * 1.5 + np.random.normal(0, 5, n)
education_levels = np.random.choice(['High School', 'Bachelor\'s', 'Master\'s'],
                                   n, p=[0.25, 0.45, 0.30])
department_levels = np.random.choice(['Engineering', 'Sales', 'Marketing', 'Support'],
                                    n, p=[0.35, 0.25, 0.20, 0.20])

# Calculate Salary
base_salary = 40000 + experience * 2500
edu_bonus = {'High School': 0, 'Bachelor\'s': 15000, 'Master\'s': 30000}
dept_effect = {'Engineering': 10000, 'Sales': 5000, 'Marketing': 2000, 'Support': 0}

salary = base_salary + \
         [edu_bonus[edu] for edu in education_levels] + \
         [dept_effect[dept] for dept in department_levels] + \
         np.random.normal(0, 8000, n)

# Pgm10 variable (Num_Projects)
is_master = np.where(education_levels == 'Master\'s', 1, 0)
log_lambda = 1.0 - 0.01 * age + 0.5 * is_master
expected_projects = np.exp(log_lambda)
num_projects = np.random.poisson(expected_projects)

# Attrition variable
prob_attrition = 1 / (1 + np.exp((salary/100000 - 1.5) + (experience/25 - 0.5)))
attrition = np.random.binomial(1, prob_attrition)
attrition_labels = np.where(attrition == 1, 'Yes', 'No')

# Final DataFrame
df = pd.DataFrame({
    'Salary': salary,
    'Experience': experience,
    'Age': age,
    'Education': education_levels,
    'Department': department_levels,
    'Attrition': attrition_labels,
    'Num_Projects': num_projects
})

print("Data Simulation Complete.")

# --- Descriptive Statistics (IQR) ---
salary_data = df['Salary']
Q1 = np.percentile(salary_data, 25)
Q3 = np.percentile(salary_data, 75)
IQR = Q3 - Q1

print("\nDescriptive Statistics (IQR)")
print(f"25th Percentile (Q1): ${Q1:,.2f}")
print(f"75th Percentile (Q3): ${Q3:,.2f}")
print(f"Interquartile Range (IQR): ${IQR:,.2f}")
print("Interpretation: The IQR gives a robust measure of the central salary spread, ignoring extreme outliers.")
print("-" * 70)

# ----------------------------------------------------------------------
# STEP 2: VISUALIZATION AND CORRELATION ANALYSIS
# ----------------------------------------------------------------------
print("STEP 2: Visualization and Correlation Analysis")

# --- Visualization: Education vs Attrition ---
print("\nCategorical Relationship: Education vs Attrition")
plt.figure(figsize=(7, 5))
cross_tab = pd.crosstab(df['Education'], df['Attrition'], normalize='index')
cross_tab[['Yes', 'No']].plot(kind='bar', stacked=True, color=['red', 'green'])
plt.title('Attrition Proportion by Education Level')
plt.ylabel('Proportion')
plt.xticks(rotation=0)
plt.tight_layout()
plt.savefig("output/attrition_by_education.png")
plt.show()
print("Saved figure: output/attrition_by_education.png")

# --- Correlation Analysis ---
print("\nNumerical Relationships (Correlation Matrix)")
numeric_df = df[['Salary', 'Experience', 'Age']]
corr_matrix = numeric_df.corr(numeric_only=True)
print("\nCorrelation Matrix:")
print(corr_matrix)

plt.figure(figsize=(6, 5))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix of Employee Features')
plt.tight_layout()
plt.savefig("output/correlation_matrix.png")
plt.show()
print("Saved figure: output/correlation_matrix.png")
print("-" * 70)

# ----------------------------------------------------------------------
# STEP 3: CENTRAL LIMIT THEOREM SIMULATION
# ----------------------------------------------------------------------
print("STEP 3: Central Limit Theorem (CLT) Simulation")

population = df['Salary']
sample_size = 50
num_samples = 300
sample_means = []

for _ in range(num_samples):
    sample = np.random.choice(population, size=sample_size, replace=False)
    sample_means.append(np.mean(sample))

plt.figure(figsize=(8, 5))
sns.histplot(sample_means, kde=True, bins=15, edgecolor='black')
plt.title(f"Distribution of Sample Means ({num_samples} samples of size {sample_size})")
plt.xlabel("Sample Mean Salary")
plt.ylabel("Frequency")
plt.axvline(np.mean(population), linestyle='--', label=f'Population Mean: ${np.mean(population):,.0f}')
plt.legend()
plt.tight_layout()
plt.savefig("output/clt_distribution.png")
plt.show()

print("CLT Interpretation: The sample means distribution approximates a normal shape,")
print("which supports using normal-based inference on the mean salary.")
print("Saved figure: output/clt_distribution.png")
print("-" * 70)

# ----------------------------------------------------------------------
# STEP 4: HYPOTHESIS TESTING
# ----------------------------------------------------------------------
print("STEP 4: Hypothesis Testing")
alpha = 0.05

# A. One-Sample t-Test
print("\nOne-Sample t-Test")
mu_0 = 85000
t_stat_1, p_value_1 = stats.ttest_1samp(df['Salary'], mu_0, alternative='less')
print(f"Hypothesis: Mean salary is significantly less than ${mu_0:,.0f}")
print(f"  T-statistic: {t_stat_1:.4f}, P-value: {p_value_1:.4f}")
if p_value_1 < alpha:
    print("  Conclusion: Reject H0. The mean salary is significantly less than the benchmark.")
else:
    print("  Conclusion: Fail to reject H0. No significant reduction found.")

# B. Two-Sample t-Test
print("\nTwo-Sample t-Test")
eng_salary = df[df['Department'] == 'Engineering']['Salary']
sales_salary = df[df['Department'] == 'Sales']['Salary']
t_stat_2, p_value_2 = stats.ttest_ind(eng_salary, sales_salary, equal_var=False)
print("Hypothesis: Mean salary is different between Engineering and Sales.")
print(f"  T-statistic: {t_stat_2:.4f}, P-value: {p_value_2:.4f}")
if p_value_2 < alpha:
    print("  Conclusion: Reject H0. There is a significant difference in average salary.")
else:
    print("  Conclusion: Fail to reject H0. No significant difference found.")

# C. Two-Proportion Z-Test
print("\nTwo-Proportion Z-Test")
sales_conversions = df[df['Department'] == 'Sales']['Attrition'].value_counts().get('Yes', 0)
sales_nobs = len(df[df['Department'] == 'Sales'])
support_conversions = df[df['Department'] == 'Support']['Attrition'].value_counts().get('Yes', 0)
support_nobs = len(df[df['Department'] == 'Support'])

conversions = np.array([sales_conversions, support_conversions])
nobs = np.array([sales_nobs, support_nobs])

z_stat_3, p_value_3 = sm.stats.proportions_ztest(count=conversions, nobs=nobs, alternative='two-sided')
print("Hypothesis: Attrition rates are different between Sales and Support.")
print(f"  Z-statistic: {z_stat_3:.4f}, P-value: {p_value_3:.4f}")
if p_value_3 < alpha:
    print("  Conclusion: Reject H0. There is a significant difference in attrition rates.")
else:
    print("  Conclusion: Fail to reject H0. No significant difference found.")
print("-" * 70)

# ----------------------------------------------------------------------
# STEP 5: MULTIPLE LINEAR REGRESSION
# ----------------------------------------------------------------------
print("STEP 5: Multiple Linear Regression (Salary ~ Experience + Education)")

df_reg = df.copy()
df_reg = pd.get_dummies(df_reg, columns=['Education'], drop_first=True)
edu_cols = [col for col in df_reg.columns if col.startswith("Education_")]

X_pgm8 = df_reg[['Experience'] + edu_cols]
X_pgm8 = sm.add_constant(X_pgm8).astype(float)
y_pgm8 = df_reg['Salary'].astype(float)

model_pgm8 = sm.OLS(y_pgm8, X_pgm8).fit()
print(model_pgm8.summary())

coef_pgm8 = model_pgm8.params
print("\nInterpretation:")
print(f"  Experience: Each additional year adds about ${coef_pgm8['Experience']:,.0f} to salary,")
print("              holding education constant.")
if "Education_Master\'s" in coef_pgm8.index:
    masters_col = "Education_Master\'s"
else:
    masters_col = [c for c in coef_pgm8.index if "Master" in c][0]
print(f"  Master's degree: Employees with a Master's earn about ${coef_pgm8[masters_col]:,.0f} more than High School,")
print("                   holding experience constant.")
print("-" * 70)

# ----------------------------------------------------------------------
# STEP 6: POISSON REGRESSION (GLM)
# ----------------------------------------------------------------------
print("STEP 6: Poisson Regression (Num_Projects ~ Age + Master's)")

# Use the dummy column created in df_reg
X_pgm10 = df_reg[['Age', masters_col]]
X_pgm10 = sm.add_constant(X_pgm10).astype(float)
y_pgm10 = df_reg['Num_Projects']

model_pgm10 = sm.GLM(y_pgm10, X_pgm10, family=sm.families.Poisson()).fit()
print(model_pgm10.summary())

coef_pgm10 = model_pgm10.params
age_multiplier = np.exp(coef_pgm10['Age'])
masters_multiplier = np.exp(coef_pgm10[masters_col])

print("\nInterpretation (Poisson):")
print(f"  Age multiplier: {age_multiplier:.4f} (expected change per additional year of age).")
print(f"  Master's multiplier: {masters_multiplier:.4f} (expected projects relative to non-Master's).")

age_ex = 40
master_ex = 1
log_lambda_calc = coef_pgm10['const'] + coef_pgm10['Age'] * age_ex + coef_pgm10[masters_col] * master_ex
lambda_calc = np.exp(log_lambda_calc)
print(f"  Example: Expected projects for a 40-year-old with a Master's: {lambda_calc:.2f} per year.")
print("-" * 70)

print("Analysis complete. Figures are saved in the 'output' directory.")
